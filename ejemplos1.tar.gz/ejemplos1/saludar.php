<?php
    /*echo '<br/>Contenido de $_POST <br/>';
    var_dump($_POST);
    echo '<br/>Contenido de $_GET <br/>';
    var_dump($_GET);
    echo '<br/>Contenido de $_SERVER <br/>';
    var_dump($_SERVER);*/
    echo "Hola {$_POST['nombre']}";
?>