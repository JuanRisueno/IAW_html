<!--Ejercicio 4: Crea una variable que almacene tu nombre y otra que almacene tu ciudad. Usa echo
para mostrar la frase "Mi nombre es [nombre] y vivo en [ciudad]".-->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $nombre = "Juan Antonio";
        $ciudad = "Bailén";
        echo "<p>Mi nombre es $nombre y mi vivo en $ciudad</p>";
    ?>    
</body>
</html>